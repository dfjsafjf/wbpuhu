<!DOCTYPE html>
<html lang="en">
<body>
    <?php
      function myTest() {
        $x = 5;
        echo "<p>Variable x inside function is: $x</p>";
      }
      myTest();
     
      echo "<p>Variable x outside function is: $x</p>";        
    ?>    
</body>
</html>