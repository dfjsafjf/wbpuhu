<html>
    <body>
        <?php
        $x = "Hello";
        $$x = "PHP";
        echo $x."<br/>";
        echo $$x."<br/>";
        echo $Hello;
        ?>
    </body>
</html>