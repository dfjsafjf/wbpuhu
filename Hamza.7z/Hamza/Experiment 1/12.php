<html>
<body>
    <?php
    $var1 = "8";
    echo gettype($var1);
    echo "<br/>";
    settype($var1, "Integer");
    echo "<br/>";
    echo gettype($var1);
    ?>
</body>

</html>