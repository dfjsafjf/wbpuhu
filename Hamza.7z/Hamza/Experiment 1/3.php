<html>
    <head>
    <title>ARRAY</title>
    </head>
    <body>
        <?php
        $var1="Hello PHP";
        $var2=5169;
        $arr= array('0'=>"Welcome",'1'=>"to",'2'=>"Hamza");
        print_r($var1);
        echo"<br/>";
        print_r($var2);
        echo"<br/>";
        print_r($arr);
        echo"<br/>";
        echo $arr[2];
        ?>
    </body>
</html>