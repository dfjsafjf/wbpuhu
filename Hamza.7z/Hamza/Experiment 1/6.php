<html>
    <head><title>vardump</title></head>
    <body>
        <?php
        $a=15;
        $b=17.30;
        $c="Hello PHP";
        $d=True;
        var_dump($a);
        echo"<br/>";
        var_dump($b);
        echo"<br/>";
        var_dump($c);
        echo"<br/>";
        var_dump($d);
        ?>
    </body>
</html>