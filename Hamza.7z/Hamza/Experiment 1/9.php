<html>
    <head>
    </head>
    <body>
        <?php
        class test
        {
            function car()
            {
                echo"This Is Test";
            }
        }
        $obj1 = new test;
        $obj1->car();
        ?>
    </body>
</html>