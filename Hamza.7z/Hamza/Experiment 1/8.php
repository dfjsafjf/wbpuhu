<html>
    <body>
        <?php
        $arr = [10,20,30,40,50];
        print_r($arr);
        ?>
    </body>
</html>