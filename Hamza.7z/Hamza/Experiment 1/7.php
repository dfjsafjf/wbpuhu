<html>
    <head><title>Array</title></head>
    <body>
        <?php
        $arr = array(1,2,3,4,5);
        echo "First Element : ".$arr[0]."<br>";
        echo "Second Element : ".$arr[1]."<br>";
        echo "Third Element : ".$arr[2];
        ?>
    </body>
</html>