<!DOCTYPE html>
<html lang="en">

<body>
    <?php
        $var1 = "Hello World";
        $var2 = 1827;
        echo $var1;
        echo "<br/>";
        echo $var2;
    ?>    

</body>
</html>