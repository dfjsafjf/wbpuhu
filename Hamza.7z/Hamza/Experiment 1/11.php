<html>
    <head><title>TypeCasting</title></head>
    <body>
        <?php
        $var1=15;
        echo $var1."<br/>";
        $var2= (double)$var1;
        echo"after converting to double <br/>";
        echo $var2."<br/>";    
        $var3= (string)$var1;
        echo"after converting to string <br/>";
        echo $var3."<br/>";    
        $var4= (boolean)$var1;
        echo"after converting to boolean <br/>";
        echo $var4;    
        ?>
    </body>
</html>