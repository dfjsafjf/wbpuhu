<html>
    <head>
        <title>Type Juggling</title>
    </head>
    <body>
        <?php
        $var1=5;
        $var2= "54";
        $var3= $var1+$var2;
        $var1 = $var1 +8.8;
        echo $var1."<br/>";
        $var1 = 5 * "10 small birds";
        echo $var1."<br/>";
        $var1 = 5 + "10 small puppies";
        echo $var1;
        ?>
    </body>
</html>