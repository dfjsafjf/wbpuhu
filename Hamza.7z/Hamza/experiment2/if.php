<!DOCTYPE html>
<html lang="en">
<body>
    <?php
        $a =16;
        if ($a>10)
        {
            echo "A is greater than 10";
        }
    ?>
</body>
</html>