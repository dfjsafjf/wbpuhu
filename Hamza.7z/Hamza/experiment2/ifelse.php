<!DOCTYPE html>
<html lang="en">
<body>
    <?php
        $a =8;
        if ($a>10)
        {
            echo "A is greater than 10";
        }
        else{
            echo "A is less than 10";
        }
    ?>
</body>
</html>