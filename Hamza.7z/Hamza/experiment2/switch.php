
<!DOCTYPE html>
<html lang="en">
<body>
<?php
    $day = "Tuesday";

    switch ($day) {
        case "Monday":
            echo "It's Monday, the start of the week!";
            break;
        case "Tuesday":
            echo "It's Tuesday, the second day of the week.";
            break;
        case "Wednesday":
            echo "It's Wednesday, halfway through the week.";
            break;
        case "Thursday":
            echo "It's Thursday, almost the weekend!";
            break;
        case "Friday":
            echo "It's Friday, time to relax!";
            break;
        default:
            echo "It's the weekend, enjoy your time off!";
}
?>

</body>
</html>