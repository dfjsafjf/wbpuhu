
<!DOCTYPE html>
<html lang="en">
<body>
    <?php
        $per=78;
        if ($per>90)
        {
            echo "Distinction ";
        }
        else if ($per>75 && $per<90){
            echo "First class";
        }
        else if ($per>50 && $per<75){
            echo "Second class";
        }
        else if ($per>35 && $per<50){
            echo "Third  class";
        }
        else{
            echo"Fail";
        }

    ?>
</body>
</html>