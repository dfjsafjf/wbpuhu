<!DOCTYPE html>
<html lang="en">
<body>
    <?php
        $i;
        for ($i=0; $i <10 ; $i++)
         {
            if ($i==4) {
                continue;
            }    
            echo $i.",";
  
     }
     ?>
</body>
</html>