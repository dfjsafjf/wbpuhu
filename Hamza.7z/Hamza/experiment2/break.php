<!DOCTYPE html>
<html lang="en">
<body>
    <?php
        $i;
        for ($i=0; $i <10 ; $i++)
         {
            echo $i.",";
            if ($i==4) {
                break;
            }      
     }
     ?>
</body>
</html>