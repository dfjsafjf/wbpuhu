<!DOCTYPE html>
<html lang="en">
<body>
    <?php
        $colors = array("red", "green", "blue");
        foreach ($colors as $color) {
            echo "The color is: $color <br>";
        }
           
    ?>
</body>
</html>