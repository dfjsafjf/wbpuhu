<!DOCTYPE html>
<html lang="en">
<body>
    <?php
        $x = 1;
        while ($x <= 5) {
            echo "The value of x is: $x <br>";
            $x++;
        }
             
    ?>
</body>
</html>