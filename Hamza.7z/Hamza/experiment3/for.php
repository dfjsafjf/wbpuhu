<!DOCTYPE html>
<html lang="en">
<body>
    <?php
        for ($i = 0; $i <= 10; $i++) {
            echo "The number is: $i <br>";
        }      
    ?>
</body>
</html>