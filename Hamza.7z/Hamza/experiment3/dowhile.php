<!DOCTYPE html>
<html lang="en">
<body>
    <?php
        $y = 10;
        do {
            echo "The value of y is: $y <br>";
            $y--;
        } while ($y >= 1);
             
    ?>
</body>
</html>