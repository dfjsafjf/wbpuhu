
<!DOCTYPE html>
<html lang="en">
<body>
        <?php
            $products = array(
                array("name" => "TV", "price" => 500),
                array("name" => "Laptop", "price" => 800)
            );

            echo "Product List: <br>";
            foreach ($products as $product) {
                echo "Product Name: " . $product["name"] . "<br>";
                echo "Product Price: $" . $product["price"] . "<br>";
                echo "<br>";
            }
        ?>

</body>
</html>