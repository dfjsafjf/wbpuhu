<!DOCTYPE html>
<html lang="en">
<body>
    <?php
            $fruits = array("apple", "banana", "orange");
            $numbers = [10, 20, 30];

            echo "Fruits: <br>";
            foreach ($fruits as $fruit) {
                echo $fruit . "<br>";
            }

            echo "Numbers: <br>";
            for ($i = 0; $i < count($numbers); $i++) {
                echo $numbers[$i] . "<br>";
            }
    ?>

</body>
</html>