
<!DOCTYPE html>
<html lang="en">
<body>
    <?php
        $a1=array("a"=>"red","b"=>"green","c"=>"blue","d"=>"yellow");
        $result=array_flip($a1);
        print_r($result);
    ?>
</body>
</html>