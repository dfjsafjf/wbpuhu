
<!DOCTYPE html>
<html lang="en">
<body>
        <?php
            $person = array("name" => "John", "age" => 30, "city" => "New York");

            echo "Person Details: <br>";
            foreach ($person as $key => $value) {
                echo "$key: $value <br>";
            }
        ?>


</body>
</html>