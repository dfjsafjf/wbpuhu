
<!DOCTYPE html>
<html lang="en">
<body>
        <?php
            $a="java";
            $b="c++";
            $c= compact("a","b");
            print_r ($c);

        ?>


</body>
</html>