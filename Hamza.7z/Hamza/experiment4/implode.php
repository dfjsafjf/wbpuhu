
<!DOCTYPE html>
<html lang="en">
<body>
        <?php
            $colors = array("red", "green", "blue");
            $separator = ", "; 
            $colorString = implode($separator, $colors);
            echo "The colors are: $colorString <br>";           
            $final = implode("", $colors);
            echo "The colors without separator: $final <br>";
        ?>


</body>
</html>