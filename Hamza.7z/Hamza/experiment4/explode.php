
<!DOCTYPE html>
<html lang="en">
<body>
    <?php
        $fruitsString = "apple, banana, orange, mango";
        $fruitsArray = explode(",", $fruitsString);
        foreach ($fruitsArray as $fruit) {
            switch ($fruit) {
                case "apple":
                    echo "Did you know an apple a day keeps the doctor away? <br>";
                    break;
                case "banana":
                    echo "Bananas are naturally curved because they grow facing the sun! <br>";
                    break;
                case "orange":
                    echo "Oranges are not only delicious, but they're also a great source of Vitamin C! <br>";
                    break;
                case "mango":
                    echo "Mangoes come in over 1,000 varieties, making them the king of fruits! <br>";
                    break;
            }
        }
    ?>
</body>
</html>